import React from 'react';
import { motion } from 'framer-motion';

const GetInTouch = () => {
  return (
    <section 
      className="relative py-24 overflow-hidden selection:bg-fuchsia-500/30 bg-white dark:bg-[#050011] transition-colors duration-500"
    >
      
      {/* --- Ambient Background Effects --- */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-purple-200 dark:bg-purple-900/20 blur-[120px] rounded-full mix-blend-multiply dark:mix-blend-screen" />
        <div className="absolute bottom-[10%] right-[-5%] w-[400px] h-[400px] bg-fuchsia-200 dark:bg-fuchsia-900/10 blur-[120px] rounded-full mix-blend-multiply dark:mix-blend-screen" />
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 dark:opacity-20 mix-blend-overlay"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Left Column: Visuals & Contact Info */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            viewport={{ once: true }}
            className="space-y-10"
          >
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-fuchsia-100 dark:bg-fuchsia-500/10 border border-fuchsia-200 dark:border-fuchsia-500/20 mb-6 backdrop-blur-md">
                 <span className="w-1.5 h-1.5 rounded-full bg-fuchsia-600 dark:bg-fuchsia-500 animate-pulse"></span>
                 <span className="text-xs font-semibold text-fuchsia-600 dark:text-fuchsia-300 uppercase tracking-wider">Contact Us</span>
              </div>
              <h2 className="text-4xl md:text-6xl font-bold text-black dark:text-white mb-6 leading-tight tracking-tight drop-shadow-sm dark:drop-shadow-xl">
                Ready to Accelerate Your <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-600 to-purple-600 dark:from-fuchsia-400 dark:via-pink-400 dark:to-purple-400">
                  Cloud Journey?
                </span>
              </h2>
              <p className="text-xl text-black dark:text-white leading-relaxed max-w-lg font-light">
                Whether you need a full-scale migration, a DevOps audit, or SRE implementation—our engineers are ready to architect your success.
              </p>
            </div>

            {/* Contact Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              
              {/* Email Card */}
              <div className="group p-6 rounded-2xl bg-white dark:bg-[#0f0518] border border-slate-200 dark:border-white/5 hover:border-fuchsia-500/30 transition-all duration-300 hover:shadow-lg dark:hover:shadow-[0_0_30px_rgba(192,38,211,0.15)] cursor-default shadow-sm">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-fuchsia-100 dark:bg-fuchsia-500/10 border border-fuchsia-200 dark:border-fuchsia-500/20 flex items-center justify-center text-fuchsia-600 dark:text-fuchsia-500 group-hover:bg-fuchsia-600 group-hover:text-white dark:group-hover:bg-fuchsia-500 transition-all duration-300 shadow-sm dark:shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-black dark:text-white mb-0.5 group-hover:text-fuchsia-600 dark:group-hover:text-fuchsia-300 transition-colors">Email Us</h4>
                    <p className="text-black-900 dark:text-white text-sm group-hover:text-black dark:group-hover:text-slate-300 transition-colors">sales@infracloudedge.com</p>
                  </div>
                </div>
              </div>

              {/* Phone Card */}
              <div className="group p-6 rounded-2xl bg-white dark:bg-[#0f0518] border border-slate-200 dark:border-white/5 hover:border-purple-500/30 transition-all duration-300 hover:shadow-lg dark:hover:shadow-[0_0_30px_rgba(168,85,247,0.15)] cursor-default shadow-sm">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-purple-100 dark:bg-purple-500/10 border border-purple-200 dark:border-purple-500/20 flex items-center justify-center text-purple-600 dark:text-purple-500 group-hover:bg-purple-600 group-hover:text-white dark:group-hover:bg-purple-500 transition-all duration-300 shadow-sm dark:shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-black dark:text-white mb-0.5 group-hover:text-purple-600 dark:group-hover:text-purple-300 transition-colors">Call Us</h4>
                    <p className="text-gray-600 dark:text-white text-sm group-hover:text-black dark:group-hover:text-slate-300 transition-colors">70460 58497</p>
                  </div>
                </div>
              </div>
            </div>

          </motion.div>


          {/* Right Column: Premium Form */}
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="bg-slate-50/80 dark:bg-[#0f0518]/60 p-8 md:p-10 rounded-[2.5rem] border border-slate-200 dark:border-white/10 backdrop-blur-xl relative shadow-xl dark:shadow-2xl"
          >
            {/* Subtle Inner Glow */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-fuchsia-200 dark:bg-fuchsia-600/10 blur-[80px] rounded-full pointer-events-none"></div>

            <form className="space-y-6 relative z-10">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-[10px] font-bold text-fuchsia-600 dark:text-fuchsia-400 uppercase tracking-widest ml-1">Full Name *</label>
                  <input 
                    type="text" 
                    id="name"
                    placeholder="Enter your name" 
                    className="w-full bg-white dark:bg-[#050011]/80 border border-slate-300 dark:border-white/10 rounded-xl px-4 py-3.5 text-black dark:text-white placeholder-slate-900 dark:placeholder-slate-100 focus:outline-none focus:border-fuchsia-500 focus:ring-1 focus:ring-fuchsia-500 transition-all shadow-sm dark:shadow-inner"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="email" className="text-[10px] font-bold text-fuchsia-600 dark:text-fuchsia-400 uppercase tracking-widest ml-1">Email Address *</label>
                  <input 
                    type="email" 
                    id="email"
                    placeholder="your@gmail.com" 
                    className="w-full bg-white dark:bg-[#050011]/80 border border-slate-300 dark:border-white/10 rounded-xl px-4 py-3.5 text-black dark:text-white placeholder-slate-900 dark:placeholder-slate-100 focus:outline-none focus:border-fuchsia-500 focus:ring-1 focus:ring-fuchsia-500 transition-all shadow-sm dark:shadow-inner"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="company" className="text-[10px] font-bold text-fuchsia-600 dark:text-fuchsia-400 uppercase tracking-widest ml-1">Company</label>
                  <input 
                    type="text" 
                    id="company"
                    placeholder="Your Company Name" 
                    className="w-full bg-white dark:bg-[#050011]/80 border border-slate-300 dark:border-white/10 rounded-xl px-4 py-3.5 text-black dark:text-white placeholder-slate-900 dark:placeholder-slate-100 focus:outline-none focus:border-fuchsia-500 focus:ring-1 focus:ring-fuchsia-500 transition-all shadow-sm dark:shadow-inner"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="phone" className="text-[10px] font-bold text-fuchsia-600 dark:text-fuchsia-400 uppercase tracking-widest ml-1">Phone</label>
                  <input 
                    type="tel" 
                    id="phone"
                    placeholder=" 00000 00000" 
                    className="w-full bg-white dark:bg-[#050011]/80 border border-slate-300 dark:border-white/10 rounded-xl px-4 py-3.5 text-black dark:text-white placeholder-slate-900 dark:placeholder-slate-100 focus:outline-none focus:border-fuchsia-500 focus:ring-1 focus:ring-fuchsia-500 transition-all shadow-sm dark:shadow-inner"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="message" className="text-[10px] font-bold text-fuchsia-600 dark:text-fuchsia-400 uppercase tracking-widest ml-1">How can we help? *</label>
                <textarea 
                  id="message"
                  rows="4"
                  placeholder="Tell us about your project goals..." 
                  className="w-full bg-white dark:bg-[#050011]/80 border border-slate-300 dark:border-white/10 rounded-xl px-4 py-3.5 text-black dark:text-white placeholder-slate-900 dark:placeholder-slate-100 focus:outline-none focus:border-fuchsia-500 focus:ring-1 focus:ring-fuchsia-500 transition-all resize-none shadow-sm dark:shadow-inner"
                ></textarea>
              </div>

              <div className="flex items-start gap-3 pt-2">
                <div className="relative flex items-center">
                  <input 
                    type="checkbox" 
                    id="privacy" 
                    className="peer h-4 w-4 cursor-pointer appearance-none rounded border border-slate-400 dark:border-white/20 bg-white dark:bg-[#050011] transition-all checked:border-fuchsia-500 checked:bg-fuchsia-500 hover:border-fuchsia-400"
                  />
                  <svg className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 text-white opacity-0 peer-checked:opacity-100 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                </div>
                <label htmlFor="privacy" className="text-xs text-black dark:text-white leading-snug cursor-pointer select-none hover:text-black/80 dark:hover:text-slate-300 transition-colors">
                  I agree to the processing of my personal data as described in the <a href="#" className="text-fuchsia-600 dark:text-fuchsia-400 hover:text-fuchsia-800 dark:hover:text-fuchsia-300 hover:underline transition-colors">Privacy Policy</a>.
                </label>
              </div>

              <motion.button
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                className="w-full py-4 px-8 bg-gradient-to-r from-fuchsia-600 to-purple-700 hover:from-fuchsia-500 hover:to-purple-600 text-white font-bold rounded-xl text-base transition-all shadow-lg dark:shadow-[0_0_20px_rgba(192,38,211,0.3)] hover:shadow-xl dark:hover:shadow-[0_0_30px_rgba(192,38,211,0.5)] border border-transparent dark:border-white/10"
              >
                Send Message
              </motion.button>

            </form>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default GetInTouch;