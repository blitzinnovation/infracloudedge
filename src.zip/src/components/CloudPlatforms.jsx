import React from 'react';
import { motion } from 'framer-motion';

const platforms = [
  {
    id: 'aws',
    name: 'Amazon Web Services',
    desc: 'The world\'s most comprehensive and broadly adopted cloud platform, offering over 200 fully featured services.',
    icon: (
      <svg viewBox="0 0 24 24" className="w-10 h-10" fill="currentColor">
        <path d="M15.524 16.516c-1.353 1.055-3.321 1.543-5.32 1.543-3.13 0-5.753-1.125-7.147-3.11-.184-.26-.008-.507.288-.363 2.112 1.05 4.706 1.637 7.218 1.637 1.892 0 3.993-.343 5.568-1.218.344-.191.568.103.393.511zm.698-1.011c-.08-.225-.262-.16-.395-.084-1.008.572-2.348.986-3.782.986-2.583 0-4.832-1.341-5.115-3.642-.016-.143.094-.236.216-.188.468.18 1.144.331 1.765.331 1.488 0 2.637-.84 2.637-2.183 0-1.258-.916-2.074-2.28-2.074-.954 0-1.854.341-2.43.896-.089.085-.205.074-.183-.053l.142-.871c.01-.065.056-.118.118-.118.576-.046 1.35-.118 2.12-.118 2.693 0 4.545 1.414 4.545 3.91 0 1.954-1.143 3.323-2.95 3.738-.2.046-.146.182.02.247 1.157.452 2.658.55 3.633.025.132-.07.25-.011.23.111l-.147.419zm1.31-2.262c-.11-.08-.093-.207.03-.277.674-.383 1.166-.69 1.166-.69.123-.075.253.014.225.155l-.176.877c-.023.115-.143.167-.243.095l-1.002-.16zm.797-3.924c.094.072.077.195-.035.255-.635.337-1.127.653-1.127.653-.119.06-.237-.024-.203-.153l.186-.713c.029-.111.148-.15.244-.083l.935.041z" />
      </svg>
    ),
    accent: "from-orange-400 to-yellow-500"
  },
  {
    id: 'azure',
    name: 'Microsoft Azure',
    desc: 'Productive, hybrid, and trusted cloud platform designed to help you bring your best ideas to life.',
    icon: (
      <svg viewBox="0 0 24 24" className="w-10 h-10" fill="currentColor">
        <path d="M5.483 21.105L1.311 16.14l4.63-2.091 3.52 7.056H5.483zm5.405 0l4.316-9.697 5.163 8.363-1.328 1.334H10.888zm5.727-11.411l2.493 4.223 3.581-1.396L16.615 9.694zM15.483 2.895L6.611 12.14l4.63 2.091 7.52-11.336h-3.278z" />
      </svg>
    ),
    accent: "from-blue-400 to-cyan-500"
  },
  {
    id: 'gcp',
    name: 'Google Cloud',
    desc: 'Leading infrastructure, platform capabilities, and industry-specific solutions to accelerate digital growth.',
    icon: (
      <svg viewBox="0 0 24 24" className="w-10 h-10" fill="currentColor">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-5-9h10v2H7z" />
      </svg>
    ),
    accent: "from-red-400 via-yellow-400 to-green-500"
  }
];

const CloudPlatforms = () => {
  return (
    <section className="relative py-20 overflow-hidden bg-white dark:bg-[#050011] transition-colors duration-500">
      {/* Background Decor */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full pointer-events-none">
        <div className="absolute top-0 left-1/4 w-64 h-64 bg-fuchsia-500/10 blur-[100px] rounded-full" />
        <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-purple-500/10 blur-[100px] rounded-full" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-fuchsia-100 dark:bg-fuchsia-500/10 border border-fuchsia-200 dark:border-fuchsia-500/20 mb-6"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-fuchsia-600 dark:bg-fuchsia-500 animate-pulse"></span>
            <span className="text-xs font-semibold text-fuchsia-600 dark:text-fuchsia-300 uppercase tracking-wider">Multi-Cloud Mastery</span>
          </motion.div>
          <h2 className="text-3xl md:text-5xl font-bold text-slate-900 dark:text-white">
            Our <span className="text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-600 to-purple-600 dark:from-fuchsia-400 dark:to-purple-400">Technology</span> Partners
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {platforms.map((platform, index) => (
            <motion.div
              key={platform.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="group relative p-8 rounded-[2.5rem] bg-slate-50 dark:bg-[#0f0518] border border-slate-200 dark:border-white/5 hover:border-fuchsia-500/30 transition-all duration-500 shadow-xl dark:shadow-none"
            >
              {/* Icon Container */}
              <div className="mb-8 relative">
                <div className={`w-20 h-20 rounded-2xl bg-white dark:bg-white/5 flex items-center justify-center shadow-lg group-hover:shadow-fuchsia-500/20 transition-all duration-500 border border-slate-100 dark:border-white/10 text-slate-600 dark:text-white group-hover:scale-110`}>
                  {platform.icon}
                </div>
                {/* Glow Effect */}
                <div className={`absolute -inset-2 bg-gradient-to-r ${platform.accent} opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-500 rounded-full`} />
              </div>

              {/* Text Content */}
              <div className="space-y-4">
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white group-hover:text-fuchsia-500 dark:group-hover:text-fuchsia-300 transition-colors">
                  {platform.name}
                </h3>
                <div className="h-1 w-12 bg-gradient-to-r from-fuchsia-500 to-purple-500 rounded-full group-hover:w-full transition-all duration-500"></div>
                <p className="text-slate-600 dark:text-white/90 text-lg leading-relaxed font-light">
                  {platform.desc}
                </p>
              </div>

              {/* Decorative Corner */}
              <div className="absolute top-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <svg className="w-6 h-6 text-fuchsia-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CloudPlatforms;     